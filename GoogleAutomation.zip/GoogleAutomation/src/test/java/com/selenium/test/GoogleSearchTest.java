package com.selenium.test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

public class GoogleSearchTest {
    public static void main(String[] args) {
     
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();

        try {
            
            driver.get("https://www.google.com");
            driver.manage().window().maximize();

            WebElement searchBox = driver.findElement(By.name("q"));
            searchBox.sendKeys("Selenium WebDriver");
            searchBox.submit();

            Thread.sleep(2000);

            WebElement resultStats = driver.findElement(By.id("result-stats"));
            System.out.println("Search Results: " + resultStats.getText());

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
       
            driver.quit();
        }
    }
}
